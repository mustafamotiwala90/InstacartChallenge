package com.mustafa.instacartchallenge.Utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.widget.Toast;


import java.util.HashSet;
import java.util.Random;
import java.util.Set;

/**
 * Simple Utils class holding some public strings for sharedPreferneces and generating a random integer.
 */
public class Utils {

    public static final String LAST_SAVED_TIME = "LAST_SAVED_TIME";
    public static final String LAST_REMAINING_TIME = "LAST_REMAINING_TIME";
    public static final String SAVED_ANSWER = "SAVED_ANSWER";

    private static Set<Integer> _usedQuizNumbers = new HashSet<>();

    public static SharedPreferences getSharedPreferences(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    /**
     * Generates a random number with the maxBound. Adds the previously used numbers in a
     * set to avoid the possibility of using the same number again.
     * @param maxBound: the upper bound to be used by the Random integer function.
     * */
    public static int generateRandom(int maxBound) {
        Random rand = new Random();
        while (true) {
            int randomNumber = rand.nextInt(maxBound);
            if (!_usedQuizNumbers.contains(randomNumber)) {
                _usedQuizNumbers.add(randomNumber);
                return randomNumber;
            }
        }
    }

}
