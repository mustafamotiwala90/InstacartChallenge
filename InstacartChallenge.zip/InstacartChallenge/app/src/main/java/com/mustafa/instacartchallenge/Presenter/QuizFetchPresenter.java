package com.mustafa.instacartchallenge.Presenter;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;

/**
 * Interface for the QuizPresenter.
 * Holds all the methods declaration to be used by {@link QuizPresenter}
 */
public interface QuizFetchPresenter {

    void parseQuestionsForQuiz(@NonNull String filepath, @NonNull Context context);

    void createAndStartCountDownTimer();

    void correctAnswerSelected();

    void saveTimeToPreferences(long remainingTime, long currentTime, @NonNull SharedPreferences preferences);

    void getTimeFromPreferenes(@NonNull SharedPreferences preferences);

    void setCountDownTimer(long time);

    void clear();

}
