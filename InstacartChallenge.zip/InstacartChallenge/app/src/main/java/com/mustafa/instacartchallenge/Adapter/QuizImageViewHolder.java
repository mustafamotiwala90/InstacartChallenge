package com.mustafa.instacartchallenge.Adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.View.OnClickListener;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.mustafa.instacartchallenge.Model.FoodItem;
import com.mustafa.instacartchallenge.R;

/**
 * Simple ViewHolder which holds just a {@link NetworkImageView}.
 * Even though its a single view, its a good rule to use viewholders whenever possible.
 * This one binds the view with the data and passes a imageloader for downloading the image.
 */
public class QuizImageViewHolder extends RecyclerView.ViewHolder {

    private final NetworkImageView _imageView;

    QuizImageViewHolder(View itemView) {
        super(itemView);
        _imageView = itemView.findViewById(R.id.quiz_image);
    }

    void bind(final FoodItem foodItem, ImageLoader loader, final FoodItemClickListener listener) {
        _imageView.setImageUrl(foodItem.getImageUrl(), loader);
        _imageView.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                listener.onItemClick(view, foodItem);
            }
        });
    }

    public NetworkImageView getImageView() {
        return _imageView;
    }

}
