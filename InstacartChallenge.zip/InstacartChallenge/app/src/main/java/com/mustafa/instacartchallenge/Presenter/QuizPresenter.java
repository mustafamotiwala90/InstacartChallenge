package com.mustafa.instacartchallenge.Presenter;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;

import com.mustafa.instacartchallenge.Base.BasePresenter;
import com.mustafa.instacartchallenge.Model.Quiz;
import com.mustafa.instacartchallenge.Network.ParseFoodItemsTask;
import com.mustafa.instacartchallenge.Network.ParseJsonTaskListener;
import com.mustafa.instacartchallenge.R;
import com.mustafa.instacartchallenge.UI.QuizView;
import com.mustafa.instacartchallenge.Utils.Utils;

/**
 * A simple presenter to parse JSON in a background task, handling showing items in the adapter
 * and starting/resetting the countdown timers.
 */
public class QuizPresenter<V extends QuizView> extends BasePresenter<V> implements QuizFetchPresenter,
        ParseJsonTaskListener {

    private ParseFoodItemsTask _parseFoodItemsTask;
    private CountDownTimer _countDownTimer;
    private static final long countDownTime = 30000;
    private static final long countDownIntervalTime = 1000;
    private Resources _resources;

    public QuizPresenter(Resources resources) {
        _resources = resources;
    }

    /**
     * Parses the JSON Response here.
     * @param filePath: The file path to questions.json for parsing
     * @param context : Passing the context to be used.
     */
    // TODO (Mustafa) : Use Weakreference here instead of passing context around
    @Override
    public void parseQuestionsForQuiz(@NonNull String filePath, @NonNull Context context) {
        _parseFoodItemsTask = new ParseFoodItemsTask(filePath, context);
        _parseFoodItemsTask.setListener(this);
        _parseFoodItemsTask.execute();
    }

    /**
     * Creates a new countdown timer.
     */
    @Override
    public void createAndStartCountDownTimer() {
        if (_countDownTimer != null) {
            _countDownTimer.cancel();
        }
        createCountDownTimer(countDownTime);
    }

    private void createCountDownTimer(long countDownTime) {
        _countDownTimer = new CountDownTimer(countDownTime, countDownIntervalTime) {
            @Override
            public void onTick(long millisUntilFinished) {
                getMvpView().showTimerText(millisUntilFinished / 1000);
            }

            @Override
            public void onFinish() {
                String message = _resources.getString(R.string.time_over);
                getMvpView().showMessage(message);
            }
        }.start();
    }

    /**
     * If the correct answer was selected then we cancel the countdown timer.
     */
    @Override
    public void correctAnswerSelected() {
        _countDownTimer.cancel();
    }

    /**
     * Using Shared Preferences to keep track of the last time the countdown timer was saved and restored.
     * @param remainingTime : Time remaining on the countdown timer.
     * @param currentTime: The current time also saved.
     */
    @Override
    public void saveTimeToPreferences(long remainingTime, long currentTime, @NonNull SharedPreferences preferences) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putLong(Utils.LAST_SAVED_TIME, currentTime);
        editor.putLong(Utils.LAST_REMAINING_TIME, remainingTime);
        editor.apply();
        _countDownTimer.cancel();
    }

    /**
     * Gets the time from preferences.
     * Calculates the time spent between pressing the home button and the current time
     * and checks if its less than the countdown timer time. If it is then we resume the timer.
     */
    @Override
    public void getTimeFromPreferenes(@NonNull SharedPreferences preferences) {
        long currentTime = System.currentTimeMillis();
        long lastSavedTime = preferences.getLong(Utils.LAST_SAVED_TIME, 0);
        long lastRemaining = preferences.getLong(Utils.LAST_REMAINING_TIME, 0);
        long timeSpent = ((currentTime - lastSavedTime) / 1000);
        if (lastRemaining != 0) {
            if (timeSpent < lastRemaining) {
                long countDownTimer = lastRemaining - timeSpent;
                getMvpView().setCountDownTime(countDownTimer);
            }
        }
    }

    @Override
    public void setCountDownTimer(long time) {
        createCountDownTimer(time * 1000);
    }

    /**
     * Clear out the memory heavy stuff such as Asynctask, listeners and the countdown timers
     */
    @Override
    public void clear() {
        if (_parseFoodItemsTask != null) {
            _parseFoodItemsTask.cancel(true);
        }
        if (_countDownTimer != null) {
            _countDownTimer.cancel();
        }
        _parseFoodItemsTask = null;
        _countDownTimer = null;
    }


    @Override
    public void sendQuiz(Quiz quiz) {
        getMvpView().showImages(quiz);
        getMvpView().startTimer();
    }
}
