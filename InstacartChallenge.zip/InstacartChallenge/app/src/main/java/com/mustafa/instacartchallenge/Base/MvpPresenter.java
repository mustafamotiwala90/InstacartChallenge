package com.mustafa.instacartchallenge.Base;

public interface MvpPresenter<V extends MvpView> {

    void onAttach(V view);

    void detach();
}
