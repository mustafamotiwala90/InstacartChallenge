package com.mustafa.instacartchallenge.Base;

/**
 * Simple Base Presenter class and adding some generic methods.
 * */
public class BasePresenter<V extends MvpView> implements MvpPresenter<V>{

    private V _mvpView;

    @Override
    public void onAttach(V view) {
        _mvpView = view;
    }

    @Override
    public void detach() {
        _mvpView = null;
    }

    public boolean isBound() {
        return _mvpView != null;
    }

    public V getMvpView() {
        return _mvpView;
    }
}

