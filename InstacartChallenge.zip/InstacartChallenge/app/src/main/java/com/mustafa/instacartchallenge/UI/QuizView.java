package com.mustafa.instacartchallenge.UI;

import com.mustafa.instacartchallenge.Base.MvpView;
import com.mustafa.instacartchallenge.Model.Quiz;

/**
 * The view implemented by {@link com.mustafa.instacartchallenge.QuizActivity} for handling all the view logic.
 */
public interface QuizView extends MvpView {

    void showImages(Quiz quiz);

    void startTimer();

    void showTimerText(long remainingTime);

    void setCountDownTime(long time);

    void retakeQuiz();

    void submitQuiz();
}
