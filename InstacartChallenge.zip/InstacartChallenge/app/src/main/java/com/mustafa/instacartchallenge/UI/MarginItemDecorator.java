package com.mustafa.instacartchallenge.UI;

import android.graphics.Rect;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.RecyclerView.State;
import android.view.View;

/**
 * Simple ItemDecorator to showing a margin between the items.
 */
public class MarginItemDecorator extends RecyclerView.ItemDecoration{

    private final int _margin;
    private final int _columns;

    public MarginItemDecorator(int margin, int columns) {
        _margin = margin;
        _columns = columns;
    }

    @Override
    public void getItemOffsets(Rect outRect, View view, RecyclerView parent, State state) {
        int position = parent.getChildLayoutPosition(view);
        outRect.right = _margin;
        outRect.bottom = _margin;

        if (position < _columns) {
            outRect.top = _margin;
        }
        // Since its 2 columns we can do a check to only set left margins for 2nd columns
        if (position % _columns == 0) {
            outRect.left = _margin;
        }
        super.getItemOffsets(outRect, view, parent, state);
    }

}
