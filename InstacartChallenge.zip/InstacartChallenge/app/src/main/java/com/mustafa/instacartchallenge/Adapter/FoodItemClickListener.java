package com.mustafa.instacartchallenge.Adapter;

import android.view.View;

import com.mustafa.instacartchallenge.Model.FoodItem;

/**
 * Simple click listeners for checking which image was clicked.
 * TODO (Mustafa) : Do not pass views around, find a better way to do this.
 */
public interface FoodItemClickListener {

    void onItemClick(View view, FoodItem item);

}
