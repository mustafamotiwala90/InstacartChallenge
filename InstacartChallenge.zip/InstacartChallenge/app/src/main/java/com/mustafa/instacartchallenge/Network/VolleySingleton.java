package com.mustafa.instacartchallenge.Network;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.LruCache;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.ImageLoader.ImageCache;
import com.android.volley.toolbox.Volley;


/**
 * Singleton Volley class used primarily for loading images.
 * Creating a LRU cache of size 20 for local use.
 */
public class VolleySingleton {

    private static VolleySingleton singletonInstance = null;
    private static final int MAX_SIZE = 20;
    private Context _context;
    private RequestQueue _requestQueue;
    private ImageLoader _imageLoader;

    public static VolleySingleton getInstance(Context context) {
        if (singletonInstance == null) {
            singletonInstance = new VolleySingleton(context);
        }
        return singletonInstance;
    }

    private VolleySingleton(Context context) {
        _context = context;
        initRequestQueue();
    }

    private void initRequestQueue() {
        _requestQueue = Volley.newRequestQueue(_context);
    }

    public void createImageLoader() {
        _imageLoader = new ImageLoader(_requestQueue, new ImageCache() {
            private final LruCache<String, Bitmap> lruCache = new LruCache<>(MAX_SIZE);
            @Override
            public Bitmap getBitmap(String url) {
                return lruCache.get(url);
            }

            @Override
            public void putBitmap(String url, Bitmap bitmap) {
                lruCache.put(url, bitmap);
            }
        });
    }

    public ImageLoader getImageLoader() {
        return _imageLoader;
    }
}

