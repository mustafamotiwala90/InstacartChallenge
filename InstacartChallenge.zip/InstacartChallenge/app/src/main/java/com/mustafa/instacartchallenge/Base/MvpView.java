package com.mustafa.instacartchallenge.Base;

/**
 * Base view used for showing a simple message on the screen
 */
public interface MvpView {
    void showMessage(String message);
}
