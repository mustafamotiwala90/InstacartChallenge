package com.mustafa.instacartchallenge.Model;

import java.util.List;

/**
 * Feed class used for keeping track of a list of quizzes.
 */
public class QuizFeed {

    public QuizFeed(List<Quiz> quizFeed) {
        _quizFeed = quizFeed;
    }

    public List<Quiz> getQuizFeed() {
        return _quizFeed;
    }

    public List<Quiz> _quizFeed;
}
