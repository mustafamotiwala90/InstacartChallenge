package com.mustafa.instacartchallenge.Adapter;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.toolbox.ImageLoader;
import com.mustafa.instacartchallenge.Model.FoodItem;
import com.mustafa.instacartchallenge.R;


import java.util.List;

/**
 * RecyclerView Adapter which holds the content list based on the json parsed.
 */
public class QuizItemsAdapter extends RecyclerView.Adapter<QuizImageViewHolder> {

    private final List<FoodItem> _quizList;
    private final ImageLoader _loader;
    private FoodItemClickListener _itemClickListener;

    public QuizItemsAdapter(@Nullable List<FoodItem> items, @NonNull ImageLoader loader,
            @NonNull FoodItemClickListener listener) {
        _quizList = items;
        _loader = loader;
        _itemClickListener = listener;
    }

    @Override
    public QuizImageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_quiz, parent, false);
        return new QuizImageViewHolder(view);
    }

    @Override
    public void onBindViewHolder(QuizImageViewHolder holder, int position) {
        if (_quizList != null) {
            FoodItem foodItem = _quizList.get(position);
            holder.bind(foodItem, _loader, _itemClickListener);
        }
    }

    @Override
    public int getItemCount() {
        if (_quizList == null) {
            return 0;
        } else {
            return _quizList.size();
        }
    }

    @Override
    public void onViewRecycled(QuizImageViewHolder holder) {
        super.onViewRecycled(holder);
        holder.getImageView().setImageDrawable(null);
    }
}
