package com.mustafa.instacartchallenge.Network;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.util.Log;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import com.mustafa.instacartchallenge.Model.FoodItem;
import com.mustafa.instacartchallenge.Model.Quiz;
import com.mustafa.instacartchallenge.Model.QuizFeed;
import com.mustafa.instacartchallenge.Utils.Utils;


import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

import java.util.List;
import java.util.Map;


/**
 * Background task to Parse the JSON and set it to the appropriate models.
 * After the parsing is finished , returns the data back to the activity for showing the images.
 */
public class ParseFoodItemsTask extends AsyncTask<String, Quiz, Quiz> {

    private String _filePath;
    @SuppressLint("StaticFieldLeak") private Context _context;
    private ParseJsonTaskListener _parseJsonTaskListener;
    private final String TAG = getClass().getName();

    //TODO(Mustafa) use this weak context reference instead of the activity one to avoid leaks.
    WeakReference<Context> _reference;

    public ParseFoodItemsTask(@NonNull String filePath, Context context) {
        _filePath = filePath;
        _context = context;
    }

    public void setListener(ParseJsonTaskListener parseJsonTaskListener) {
        _parseJsonTaskListener = parseJsonTaskListener;
    }

    @Override
    protected Quiz doInBackground(String... strings) {
        JsonObject quizObject = getJSONResource(_context);
        QuizFeed quizFeed = getQuizFeed(quizObject);
        int quizNumber = Utils.generateRandom(quizFeed.getQuizFeed().size());
        return quizFeed.getQuizFeed().get(quizNumber);
    }

    @Override
    protected void onPostExecute(Quiz quiz) {
        super.onPostExecute(quiz);
        _parseJsonTaskListener.sendQuiz(quiz);
    }

    /**
     * Get the Feed from the JSON blob. We parse each individual sub object
     * and get the title and the image list associated with it.
     * Structure of JSON is as follows :
     * {title } : [
     *          {imageLink},
     *          {imageLink},
     *          {imageLink},
     *          {imageLink}
     *          ],
     * */
    private QuizFeed getQuizFeed(JsonObject quizObject) {
        List<Quiz> quizzes = new ArrayList<>();
        for (Map.Entry<String, JsonElement> entry : quizObject.entrySet()) {
            String title = entry.getKey();
            List<FoodItem> imageList = getImagesList((JsonArray) entry.getValue());
            Quiz quiz = new Quiz(title, imageList);
            quizzes.add(quiz);
        }
        return new QuizFeed(quizzes);
    }

    /**
     * Parses through the json object blob to only get the list of images
     * */
    private List<FoodItem> getImagesList(JsonArray jsonArray) {
        List<FoodItem> imageList = new ArrayList<>();
        for (int i = 0; i < jsonArray.size(); i++) {
            imageList.add(new FoodItem(jsonArray.get(i).getAsString()));
        }
        return imageList;
    }

    /**
     * Parses the file to grab the original JSON Object which contains sub-objects of a title and 4 images.
     * */
    private JsonObject getJSONResource(Context context) {
        try (InputStream is = context.getAssets().open(_filePath)) {
            JsonParser parser = new JsonParser();
            return parser.parse(new InputStreamReader(is)).getAsJsonObject();
        } catch (Exception e) {
            Log.e(TAG, e.getMessage(), e);
        }
        return null;
    }

    @Override
    protected void onCancelled(Quiz quiz) {
        _context = null;
        _parseJsonTaskListener = null;
        super.onCancelled(quiz);
    }
}
