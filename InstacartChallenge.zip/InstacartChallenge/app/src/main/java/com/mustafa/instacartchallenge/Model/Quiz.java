package com.mustafa.instacartchallenge.Model;


import java.util.List;

/**
 * Simple Feed class which holds a list of FoodItem{@link FoodItem}.
 * Also contains question of the quiz.
 */
public class Quiz {

    private String _questionTitle;
    private List<FoodItem> _foodItemList;
    private int _correctAnswer = 0;

    public Quiz(String questionTitle, List<FoodItem> foodItemList) {
        _questionTitle = questionTitle;
        _foodItemList = foodItemList;
    }

    public String getQuestionTitle() {
        return _questionTitle;
    }

    public List<FoodItem> getFoodItemList() {
        return _foodItemList;
    }

    public FoodItem getCorrectFoodItem() {
        return _foodItemList.get(_correctAnswer);
    }

    public void setCorrectAnswer(int index) {
        _correctAnswer = index;
    }
}

