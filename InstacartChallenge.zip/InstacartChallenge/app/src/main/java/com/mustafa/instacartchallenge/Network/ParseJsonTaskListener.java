package com.mustafa.instacartchallenge.Network;

import com.mustafa.instacartchallenge.Model.Quiz;

public interface ParseJsonTaskListener {

    void sendQuiz(Quiz quiz);
}
