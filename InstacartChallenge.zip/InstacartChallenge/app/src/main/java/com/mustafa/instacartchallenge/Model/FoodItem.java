package com.mustafa.instacartchallenge.Model;

/**
 * Simple model class to hold a food item.
 * Overriding the equals() method so that two FoodItem could be compared.
 * */
public class FoodItem {

    private String _imageUrl;

    public FoodItem(String imageUrl) {
        _imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return _imageUrl;
    }

    @Override
    public boolean equals(Object o)
    {
        if (o instanceof FoodItem)
        {
            FoodItem c = (FoodItem) o;
            if ( this._imageUrl.equals(c._imageUrl) )
                return true;
        }
        return false;
    }
}
