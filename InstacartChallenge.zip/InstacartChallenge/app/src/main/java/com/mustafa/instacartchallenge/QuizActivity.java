package com.mustafa.instacartchallenge;

import android.app.Activity;
import android.content.SharedPreferences;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.mustafa.instacartchallenge.Adapter.FoodItemClickListener;
import com.mustafa.instacartchallenge.Adapter.QuizImageViewHolder;
import com.mustafa.instacartchallenge.Adapter.QuizItemsAdapter;
import com.mustafa.instacartchallenge.Model.FoodItem;
import com.mustafa.instacartchallenge.Model.Quiz;
import com.mustafa.instacartchallenge.Network.VolleySingleton;
import com.mustafa.instacartchallenge.Presenter.QuizPresenter;
import com.mustafa.instacartchallenge.UI.FadingItemAnimator;
import com.mustafa.instacartchallenge.UI.MarginItemDecorator;
import com.mustafa.instacartchallenge.UI.QuizView;
import com.mustafa.instacartchallenge.Utils.Utils;


import java.lang.ref.WeakReference;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

import static com.mustafa.instacartchallenge.Utils.Utils.SAVED_ANSWER;

public class QuizActivity extends AppCompatActivity implements QuizView, FoodItemClickListener {

    QuizPresenter<QuizView> _quizPresenter;
    public static final String QUESTIONS_JSON = "questions.json";
    public static final int COLUMN_COUNT = 2;
    private ImageLoader imageLoader;
    private long _lastRemainingTime;


    @BindView(R.id.quiz_image_rv) RecyclerView _quizRecyclerView;
    @BindView(R.id.quiz_title) public TextView _quizTitle;
    @BindView(R.id.quiz_timer) TextView _quizTimer;
    @BindView(R.id.retake_quiz) Button _retakeQuiz;
    @BindView(R.id.submit_quiz) Button _submitQuiz;

    private Quiz _quiz;
    private FoodItem _selectedItem;

    //TODO Mustafa Implement a WeakReference for use and pass it around instead of context
    WeakReference<Activity> weakActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);
        ButterKnife.bind(this);

        VolleySingleton.getInstance(this).createImageLoader();
        _quizPresenter = new QuizPresenter<>(getResources());
        _quizPresenter.onAttach(this);
        _quizPresenter.parseQuestionsForQuiz(QUESTIONS_JSON, this);

        initImageLoader();
        initRecyclerView();
    }

    private void initImageLoader() {
        imageLoader = VolleySingleton.getInstance(this).getImageLoader();
    }

    private void initRecyclerView() {
        _quizRecyclerView.setClickable(true);
        _quizRecyclerView.setHasFixedSize(true);
        StaggeredGridLayoutManager gridLayoutManager = new StaggeredGridLayoutManager(COLUMN_COUNT,
                StaggeredGridLayoutManager.VERTICAL);
        MarginItemDecorator marginItemDecorator = new MarginItemDecorator(
                getResources().getDimensionPixelOffset(R.dimen.item_margin), COLUMN_COUNT);
        _quizRecyclerView.addItemDecoration(marginItemDecorator);
        _quizRecyclerView.setItemAnimator(new FadingItemAnimator());
        _quizRecyclerView.setLayoutManager(gridLayoutManager);
    }

    @Override
    protected void onPause() {
        super.onPause();
        long currentTime = System.currentTimeMillis();
        _quizPresenter.saveTimeToPreferences(_lastRemainingTime, currentTime, Utils.getSharedPreferences(this));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (_quizPresenter.isBound()) {
            _quizPresenter.getTimeFromPreferenes(Utils.getSharedPreferences(this));
        }
    }

    @Override
    protected void onDestroy() {
        SharedPreferences sharedPreferences = Utils.getSharedPreferences(this);
        sharedPreferences.edit().clear().apply();
        _quizPresenter.clear();
        _quizPresenter.detach();
        super.onDestroy();
    }

    @Override
    public void showMessage(String message) {
        Utils.showToast(this, message);
    }

    @Override
    public void showImages(Quiz quiz) {
        QuizItemsAdapter recyclerAdapter = new QuizItemsAdapter(quiz.getFoodItemList(), imageLoader, this);
        _quiz = quiz;
        _quizRecyclerView.setAdapter(recyclerAdapter);
        _quizTitle.setText(getString(R.string.question_title, quiz.getQuestionTitle()));
        quiz.setCorrectAnswer(Utils.generateRandom(quiz.getFoodItemList().size()));
    }

    @Override
    public void startTimer() {
        _quizPresenter.createAndStartCountDownTimer();
    }

    @Override
    public void showTimerText(long timeRemaining) {
        String remainingTime = getString(R.string.current_timer, timeRemaining);
        _lastRemainingTime = timeRemaining;
        _quizTimer.setText(remainingTime);
    }

    @Override
    public void setCountDownTime(long time) {
        _quizPresenter.setCountDownTimer(time);
    }

    @OnClick(R.id.retake_quiz)
    @Override
    public void retakeQuiz() {
        _quizPresenter.createAndStartCountDownTimer();
        _quizTimer.setVisibility(View.VISIBLE);
        removeColorFilters();
        _selectedItem = null;
    }

    @OnClick(R.id.submit_quiz)
    @Override
    public void submitQuiz() {
        if (_selectedItem == null) {
            Utils.showToast(this, getString(R.string.select_answer_error));
            return;
        }
        SharedPreferences sharedPreferences = Utils.getSharedPreferences(this);
        sharedPreferences.edit().putString(SAVED_ANSWER, _selectedItem.getImageUrl()).apply();
        Utils.showToast(this, getString(R.string.answer_saved));
    }

    private void removeColorFilters() {
        for (int i = 0; i < _quizRecyclerView.getChildCount(); i++) {
            QuizImageViewHolder holder = (QuizImageViewHolder) _quizRecyclerView.findViewHolderForAdapterPosition(i);
            holder.getImageView().setColorFilter(null);
        }
    }

    @Override
    public void onItemClick(View view, FoodItem item) {
        // Check if the right value was selected.
        if (view instanceof NetworkImageView) {
            if (_quiz.getCorrectFoodItem() == item) {
                _selectedItem = item;
                ((NetworkImageView) view).setColorFilter(
                        ContextCompat.getColor(this, R.color.quiz_right_semi_transparent));
                Utils.showToast(this, getString(R.string.right_answer));
                _quizPresenter.correctAnswerSelected();
                _quizTimer.setVisibility(View.GONE);
            } else {
                ((NetworkImageView) view).setColorFilter(
                        ContextCompat.getColor(this, R.color.quiz_wrong_semi_transparent));
                Utils.showToast(this, getString(R.string.wrong_answer));
            }
        }
    }
}
