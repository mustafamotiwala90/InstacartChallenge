package com.mustafa.instacartchallenge;

import android.content.res.Resources;

import com.mustafa.instacartchallenge.Presenter.QuizPresenter;
import com.mustafa.instacartchallenge.UI.QuizView;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;


import static org.mockito.Mockito.verify;

/**
 * Tests for the main presenter {@link QuizPresenter}
 */
@RunWith(MockitoJUnitRunner.class)
public class QuizPresenterTest {

    @Mock QuizView _quizView;

    @Mock Resources _resources;

    private QuizPresenter<QuizView> _quizPresenter;

    @BeforeClass
    public static void onlyOnce() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
        _quizPresenter = new QuizPresenter<>(_resources);
        _quizPresenter.onAttach(_quizView);
    }

    @Test
    public void testImagesShown() {

    }

    @Test
    public void testEmpty() {

    }

    @Test
    public void testTimerRunning() {

    }


    @After
    public void tearDown() throws Exception {
        _quizPresenter.detach();
    }

}
